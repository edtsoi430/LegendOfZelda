﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour {
    public GameObject rupeePrefab;
    public GameObject heartPrefab;
    public GameObject bombPrefab;
    public GameObject bigHeartPrefab;
    public Vector2 movement;
    public AudioClip die_sound;
    public Rigidbody rb;
    public SpriteRenderer sr;
    public Sprite last_sprite;

    public float speed;
    public float flashing_time;
    public float duration_time;
    public float sprite_time;
    public float start_time;
    public int health;
    public bool stop;
    public float stop_time;
    public float stop_duration;

    public bool is_boss = false;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        sr = GetComponent<SpriteRenderer>();
        last_sprite = sr.sprite;
        sprite_time = Time.time;
        start_time = Time.time;
        stop = false;
        stop_duration = 3;
    }


    // Update is called once per frame
    public virtual void Update()
    {
        if (health == 0)
        {
            if (!is_boss)
            {
                ItemsReward();
            }
            else
            {
                BossReward();
            }
            Destroy(gameObject);
            AudioSource.PlayClipAtPoint(die_sound, Camera.main.transform.position);
        }

    }

    public virtual Vector2 randomMove()
    {
        return new Vector2(0, 0);
    }

    void OnTriggerEnter(Collider other)
    {
        GameObject go = other.gameObject;
        if (go.tag == "weapon_damage")
        {
            health--;
        }
        else if (go.tag == "weapon_returning")
        {
            stop = true;
            stop_time = Time.time;
        }
        else if (go.tag == "explosive")
        {
            health = 0;
        }
    }

    private void ItemsReward()
    {
        int random = Random.Range(0, 8);
        if (random == 0 && random == 1)
        {
            Instantiate(rupeePrefab, transform.position, Quaternion.identity);
        }
        else if (random == 2)
        {
            Instantiate(heartPrefab, transform.position, Quaternion.identity);
        }
        else if (random == 3)
        {
            Instantiate(bombPrefab, transform.position, Quaternion.identity);
        }
    }

    public void StopCheck()
    {
        if (Time.time - stop_time > stop_duration && stop)
        {
            stop = false;
        }
    }

    public void BossReward()
    {
        Instantiate(bigHeartPrefab, transform.position, Quaternion.identity);
    }
}
