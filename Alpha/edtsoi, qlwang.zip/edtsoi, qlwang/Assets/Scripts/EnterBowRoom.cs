﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnterBowRoom : MonoBehaviour {

    private void OnTriggerEnter(Collider other)
    {

    }
}
