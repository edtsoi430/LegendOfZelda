﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class blockControl : MonoBehaviour {
    public Transform t1;

    public GameObject gel1;
    public GameObject gel2;
    public GameObject gel3;

    public AudioClip moveBlock_sound;

    private bool blockMovable = false;
    private int count = 0;
    private void Update()
    {
        if(gel1 == null && gel2 == null && gel3 == null){
            blockMovable = true;
        }
    }
    //   public float dist = 1f;
    //   public LayerMask blockMask;
    //// Update is called once per frame
    //void Update () {
    //       Physics.queriesHitTriggers = false;
    //       Physics.Raycast(transform.position, Vector3.right * transform.localScale.x, dist, blockMask);
    //}
    private void OnCollisionStay(Collision collision)
    {
        if(collision.gameObject.tag == "Player" && blockMovable)
        {
            transform.position = Vector3.MoveTowards(transform.position, t1.position, Time.deltaTime * 8);
            if(count == 0){
                count++;
                AudioSource.PlayClipAtPoint(moveBlock_sound, Camera.main.transform.position);
            }
        }
    }
}
