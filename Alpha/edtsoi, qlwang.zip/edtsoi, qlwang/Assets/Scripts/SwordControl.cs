﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SwordControl : MonoBehaviour {

	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
		
	}
    void OnCollisionEnter(Collision collision)
    {
        
    }
    //public void shootR()
    //{
    //    rb2d.AddForce(new Vector2(500, 0));
    //}
}
