﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireSingleton : MonoBehaviour {

    private void OnTriggerEnter(Collider other)
    {
        GameObject go = other.gameObject;
        if (go.tag == "wall" || go.tag == "door" || go.tag == "aisle")
        {
            Destroy(gameObject);
        }
    }

}
