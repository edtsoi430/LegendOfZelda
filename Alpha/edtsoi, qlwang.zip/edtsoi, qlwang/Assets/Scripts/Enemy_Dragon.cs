﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Dragon : Enemy {

    public GameObject fires;

    private float fire_time = 3f;
    private float firing_start;
    private bool movingLeft = true;

	void Start () {
        health = 4;
        firing_start = Time.time;
        is_boss = true;
    }
    
    public override void Update()
    {
        if (Time.time - firing_start > fire_time)
        {
            firing_start = Time.time;
            Instantiate<GameObject>(fires, transform.position, Quaternion.identity);
        }
        base.Update();
    }
}
