﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour {

    public CamFollowing main_camera;
    public Text health_text;
    public GameObject dead_curtain;
    public GameObject black;

    public float full_health;
    public float current_health;
    public bool invincible;

    public AudioClip pick_up_heart_sound;
    public AudioClip pick_up_bomb_sound;
    //public AudioClip pick_up_

    private IEnumerator coroutine;
    private ArrowKeyMovement arm;

    void Awake() {
        current_health = 3f;
        full_health = 3f;

        health_text.text = "Health: " + current_health.ToString() + " / " + full_health.ToString();
        arm = GetComponent<ArrowKeyMovement>();
    }

    private void Update()
    {
        if (arm.dead && Input.GetKeyDown(KeyCode.Space))
        {
            restart();
        }

        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            invincible = true;
            GetComponent<Inventory>().AddRupees(99);
            GetComponent<Inventory>().AddKeys(99);
            GetComponent<Inventory>().AddBombs(99);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        GameObject go = other.gameObject;
        if (go.tag == "aisle")
        {
            main_camera.moveCam();
        }

        if (go.tag == "enterBowRoom"){
            main_camera.transform.position = new Vector3(-4.5f, 22f, -20f);
            transform.position = new Vector3(-10, 23, 0);
        }
        if (go.tag == "backTo")
        {
            main_camera.transform.position = new Vector3(23.5f, 62f, -20f);
            transform.position = new Vector3(23, 60, 0);
        }

        if (go.tag == "heart")
        {
            current_health++;
            health_text.text = "Health: " + current_health.ToString() + " / " + full_health.ToString();
            Destroy(go);
            AudioSource.PlayClipAtPoint(pick_up_heart_sound, Camera.main.transform.position);
        }

        if (go.tag == "wall_master")
        {
            arm.catching = true;
            arm.GetCaught(go);
        }

        if (go.tag == "bomb")
        {
            Destroy(go);
            AudioSource.PlayClipAtPoint(pick_up_bomb_sound, Camera.main.transform.position);
        }

        if (go.tag == "boomerangC")
        {
            Destroy(go);
            GetComponent<WeaponControl>().has_boomerang = true;
            AudioSource.PlayClipAtPoint(pick_up_bomb_sound, Camera.main.transform.position);
        }

        if (go.tag == "bowC")
        {
            Destroy(go);
            GetComponent<WeaponControl>().has_bow = true;
            AudioSource.PlayClipAtPoint(pick_up_bomb_sound, Camera.main.transform.position);
        }


        if (go.tag == "big_heart")
        {
            Destroy(go);
            full_health++;
            health_text.text = "Health: " + current_health.ToString() + " / " + full_health.ToString();
            AudioSource.PlayClipAtPoint(pick_up_bomb_sound, Camera.main.transform.position);
        }

        if (go.tag == "full_health")
        {
            Destroy(go);
            current_health = full_health;
            health_text.text = "Health: " + current_health.ToString() + " / " + full_health.ToString();
            AudioSource.PlayClipAtPoint(pick_up_bomb_sound, Camera.main.transform.position);
        }

    }

    private void OnCollisionEnter(Collision collision)
    {
        GameObject go = collision.gameObject;
        if (go.tag == "ghost")
        {
            if(invincible == false)
            {
                current_health = current_health - 0.5f;
                if (current_health <= 0) PlayerDead();
                health_text.text = "Health: " + current_health.ToString();
                GetComponent<SpriteRenderer>().color = Color.red;
                invincible = true;
                arm.knockingBack();
                coroutine = Invinciblity(1f);
                StartCoroutine(coroutine);
            }
        }
    }

    IEnumerator Invinciblity (float time)
    {
        yield return new WaitForSeconds(time);
        GetComponent<SpriteRenderer>().color = Color.white;
        invincible = false;
    }

    private void PlayerDead ()
    {
        dead_curtain.SetActive(true);
        coroutine = DeadInfo(20f);
        StartCoroutine(coroutine);
    }

    IEnumerator DeadInfo (float time)
    {
        GetComponent<SpriteRenderer>().color = Color.white;
        arm.dead = true;
        yield return new WaitForSeconds(time);
    }

    private void restart ()
    {
        SceneManager.LoadScene("MainScene");
    }

    public bool isFullHealth()
    {
        if (current_health < full_health)
        {
            return false;
        }

        return true;
    }

    public void GoBack()
    {
        coroutine = GoBackToOriginal(2f);
        StartCoroutine(coroutine);
    }

    IEnumerator GoBackToOriginal(float time)
    {
        arm.camera_moving = true;
        black.SetActive(true);
        GetComponent<SpriteRenderer>().sortingOrder = -99;
        transform.position = new Vector2(39.5f, 2.5f);
        main_camera.transform.position = new Vector3(39.5f, 7f, -20f);
        yield return new WaitForSeconds(time);
        arm.camera_moving = false;
        black.SetActive(false);
        GetComponent<SpriteRenderer>().sortingOrder = 1;
    }
}
