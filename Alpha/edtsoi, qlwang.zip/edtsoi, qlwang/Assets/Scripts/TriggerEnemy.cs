﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerEnemy : MonoBehaviour {

    public GameObject enemy;

    private void OnTriggerEnter(Collider other)
    {
        if (!enemy.activeSelf)
        {
            enemy.SetActive(true);
            enemy.GetComponent<EnemyControl>().SetPosition();
        }
    }
}
