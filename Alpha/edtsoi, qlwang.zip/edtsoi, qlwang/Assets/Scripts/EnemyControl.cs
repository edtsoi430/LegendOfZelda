﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyControl : MonoBehaviour {

    public Enemy[] enemies;
    public Vector3[] spawn_position;

    public GameObject room;

    private int counter = 0;

	// Use this for initialization
	void Awake () {
        enemies = GetComponentsInChildren<Enemy>();
        SetPosition();
    }
	
	// Update is called once per frame
	void Update () {
		
	}

    public void SetPosition()
    {
        counter = 0;
        foreach (Enemy enemy in enemies)
        {
            if(enemy != null){
                enemy.transform.position = spawn_position[counter];
                enemy.GetComponent<BoundryCheck>().enabled = true;
                enemy.GetComponent<BoundryCheck>().SetRoom(room);
                counter++;
            }
        }
    }
}
