﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fire : MonoBehaviour {

    private Rigidbody[] rbs;

    private void Awake()
    {
        rbs = GetComponentsInChildren<Rigidbody>();

        rbs[0].velocity = new Vector2(-1, 1);
        rbs[1].velocity = new Vector2(-1, 0);
        rbs[2].velocity = new Vector2(-1, -1);
    }

}
